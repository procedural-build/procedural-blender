
class MultipleObjectsReturned(Exception):
    pass


class DoesNotExist(Exception):
    pass
